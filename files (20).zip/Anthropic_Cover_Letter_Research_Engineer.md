# Anthropic - Research Engineer, Production Model Post Training
## Cover Letter Template

---

Derek Lankeaux
West Babylon, NY
derek.lankeaux@email.com
linkedin.com/in/dereklankeaux

[Date]

Hiring Team
Anthropic
San Francisco, CA

Dear Hiring Manager,

I'm writing to apply for the Research Engineer, Production Model Post Training position at Anthropic. As an AI Quality Assurance Specialist at Toloka AI, I evaluate frontier LLM outputs (GPT-4, Claude-3, Gemini) daily, architecting evaluation pipelines that process 10K+ inference requests with 99.9% reliability. My MS in Applied Statistics from RIT, production ML experience, and deep expertise in Bayesian methods uniquely position me to bridge research and engineering in developing reliable, interpretable AI systems through robust post-training processes.

**Production ML Systems at Scale**

My current work at Toloka AI directly parallels post-training evaluation workflows. I've built distributed testing frameworks that systematically evaluate frontier model outputs across multiple dimensions—quality, safety, and capability assessments. This experience includes implementing fault-tolerant pipelines with automatic retry logic, comprehensive monitoring, and statistical validation using reliability metrics (Krippendorff's α, Cohen's κ). I thrive in the "controlled chaos" environment you describe, regularly juggling multiple urgent priorities while maintaining clarity when debugging complex, time-sensitive issues in production systems.

**LLM Ensemble Research and Bayesian Inference**

My graduate research demonstrates my ability to work with frontier models at production scale. I orchestrated 67,500 API calls across GPT-4, Claude-3, and Llama-3, implementing robust error handling, rate limiting, and parallel processing. This project mirrors post-training workflows—coordinating multiple models, systematic evaluation, and production-grade reliability. My expertise in Bayesian hierarchical modeling with PyMC (MCMC sampling, convergence diagnostics, posterior inference) brings rigorous statistical evaluation to model training pipelines. I understand how to quantify uncertainty, model hierarchical effects, and make principled decisions under ambiguity—critical skills for post-training recipe development.

**Engineering Rigor and Performance Optimization**

I balance research exploration with engineering excellence. Recent work includes optimizing a distributed LLM pipeline by 5-10x through systematic profiling, vectorization, and parallel processing (documented in PERFORMANCE_REPORT.md). I've built production NL2SQL systems with LangChain, reducing query latency from 2.1s to 0.3s through embedding optimization and caching strategies. My healthcare ML project achieved 99.12% accuracy with a fault-tolerant architecture including REST API, Docker containerization, and <100ms inference latency. I approach every project with production deployment in mind—comprehensive testing, monitoring, and operational reliability.

**Why Anthropic**

I'm deeply aligned with Anthropic's mission to create reliable, interpretable, and steerable AI systems. Your research on Constitutional AI, RLHF, and scaling laws represents exactly the kind of "big science" ML research I want to contribute to. The opportunity to work on post-training processes that directly impact how Claude learns, generalizes, and aligns with human values is precisely where I want to apply my unique combination of statistical rigor and systems engineering.

My background in Bayesian methods provides a principled framework for thinking about preference modeling, uncertainty quantification, and robust evaluation—all critical to effective RLHF and Constitutional AI implementations. I'm excited by the prospect of translating cutting-edge research into production-ready post-training techniques at Anthropic's scale.

**Technical Foundation and Python Proficiency**

I work exclusively in Python for all ML development, with advanced proficiency in PyMC, scikit-learn, PyTorch concepts, distributed computing libraries, and modern ML development practices. I'm comfortable with large-scale distributed systems, high-performance computing, and navigating the ambiguity inherent in fast-moving research environments. My experience spans the full ML lifecycle—from research and experimentation through robust production deployment with monitoring and reliability engineering.

**Availability and Commitment**

I'm open to working in-person in your SF, NYC, or Seattle office 25%+ of the time and can start within 2-4 weeks. I'm prepared for the on-call responsibilities inherent in production model training and excited about the collaborative, high-impact research discussions you describe. The opportunity to be "results-oriented with a bias towards flexibility and impact" resonates strongly with my approach to ML engineering.

I'd welcome the opportunity to discuss how my experience with frontier LLMs, Bayesian inference, and production ML systems can contribute to Anthropic's post-training efforts. Thank you for considering my application.

Sincerely,
Derek Lankeaux

---

**Attachments:**
- Resume (Derek_Lankeaux_Resume_2026_AI_Optimized.pdf)
- GitHub: github.com/dereklankeaux
- LinkedIn: linkedin.com/in/dereklankeaux

---

## Key Points to Emphasize in Interview

**If Asked About Production ML:**
"At Toloka, I process 10K+ LLM inferences daily with 99.9% reliability. This required building distributed evaluation systems with fault tolerance—automatic retry logic, circuit breakers, comprehensive monitoring. When API latency spikes or error rates increase, I debug systematically, often under time pressure with multiple stakeholders waiting. This mirrors the 'controlled chaos' you described."

**If Asked About RLHF/Constitutional AI:**
"My Bayesian hierarchical modeling work provides the statistical foundation for preference modeling. In my research, I modeled how different evaluators (analogous to different human preferences) systematically vary, using hierarchical structures to share statistical strength. This directly relates to RLHF—modeling human preferences with uncertainty quantification and robust aggregation across diverse feedback."

**If Asked About Scale:**
"I've coordinated 67,500 API calls with rate limiting, error handling, and parallel processing. My performance optimization work shows I think about scalability—profiling bottlenecks, vectorizing operations, implementing caching. For healthcare ML, I benchmarked training time across ensemble methods and optimized by 10x. I approach every problem asking 'how does this scale to 10x or 100x the data?'"

**If Asked About Python Proficiency:**
"All my work is in Python. I'm proficient with scientific stack (NumPy, pandas, scikit-learn), deep learning frameworks conceptually (PyTorch patterns), Bayesian tools (PyMC, ArviZ), async programming for API coordination, and production deployment (FastAPI, Docker). I write modular, well-tested code with clear documentation."

**If Asked "Why Anthropic?":**
"Three reasons: (1) Mission alignment—I care deeply about building AI systems that are reliable and beneficial. Your Constitutional AI research represents principled approaches to alignment. (2) Research quality—papers on scaling laws, mechanistic interpretability, and RLHF are exactly the rigorous, empirical AI research I want to contribute to. (3) Impact—post-training directly shapes how millions of users experience Claude. The opportunity to improve model capabilities, safety, and alignment at that scale is incredibly motivating."

**If Asked About Handling Ambiguity:**
"In my LLM ensemble research, there was no clear 'right answer' for how to aggregate three models with different failure modes and biases. I approached it systematically: (1) Bayesian hierarchical modeling to quantify uncertainty, (2) Multiple validation metrics to assess different quality dimensions, (3) Sensitivity analyses to understand robustness. When debugging production issues at Toloka with incomplete information, I prioritize high-impact hypotheses, instrument carefully, and iterate quickly."

**If Asked About Collaboration:**
"I've collaborated with product managers at BRdata on NL2SQL requirements, with domain experts on healthcare ML validation, and with fellow researchers on statistical methodology. I enjoy pair programming and learn fastest through collaborative problem-solving. The 'frequent research discussions' you mentioned align perfectly with how I like to work—staying connected to the highest-impact problems and benefiting from diverse perspectives."

---

## Questions to Ask Anthropic

**About the Role:**
1. "What does a typical week look like for a Research Engineer on the Post-Training team? What's the balance between heads-down engineering, research discussions, and cross-team collaboration?"

2. "How do you balance research exploration (trying new post-training techniques) with production reliability (maintaining consistent model quality)? What's the decision-making process when a new approach looks promising but introduces risk?"

3. "Can you describe a recent post-training challenge the team faced and how it was resolved? I'm curious about the kinds of problems that come up and how the team approaches them."

**About Technical Depth:**
4. "What ML frameworks and tools does the post-training team primarily use? Are there specific technologies I should deepen my expertise in?"

5. "How do you evaluate post-training recipe effectiveness? What metrics matter most—capability benchmarks, safety evals, user satisfaction, or something else?"

6. "The role mentions responding to incidents on short notice, including weekends. Can you share more about what those incidents typically look like and how the on-call rotation works?"

**About Anthropic Culture:**
7. "You describe Anthropic as working 'as a single cohesive team on just a few large-scale research efforts.' How does the Post-Training team fit into this larger research agenda? What are the main efforts right now?"

8. "The job description mentions valuing 'communication skills' and 'frequent research discussions.' Can you describe how those discussions typically work? Are they structured presentations, informal whiteboarding, or something else?"

9. "What does success look like for someone in this role in their first 6 months? What would be meaningful early contributions?"

**About Growth:**
10. "Are there opportunities to contribute to Anthropic's research publications while in this role? I'm interested in both engineering impact and research contribution."

11. "How do Research Engineers typically grow at Anthropic? What might career progression look like?"

---

## Additional Notes

**Salary Expectations:**
- Posted range: $315K-$340K
- Target: $330K-$340K (position at high end given LLM expertise + statistical depth)
- Walk-away: <$310K (below market for your skills)

**Timeline:**
- Can start: 2-4 weeks notice
- Relocation: Open to SF/NYC/Seattle, preference for remote-first with 25% in-office
- Deadline pressures: None currently, but ideally start by Q1 2026

**Red Flags to Watch:**
- Excessive on-call burden (>1 week/month)
- Limited autonomy in technical decisions
- Unclear research vs. pure ops split
- Poor work-life balance indicators

**Green Flags to Look For:**
- Clear career growth path
- Research publication opportunities
- Collaborative, high-caliber team
- Meaningful impact on Claude's capabilities
- Strong alignment culture (mission-driven)
