# 🎯 Anthropic Research Engineer Application Package
## Ready-to-Submit Materials for Derek Lankeaux

**Position:** Research Engineer, Production Model Post Training  
**Company:** Anthropic  
**Salary:** $315,000 - $340,000 USD  
**Match Score:** 75% ⭐ EXCELLENT FIT

---

## 📦 Your Complete Application Package

### 1. Resume ✅
**File:** `Derek_Lankeaux_Resume_Anthropic_PostTraining.txt`  
**Status:** Content complete - needs PDF formatting  
**Action:** Follow `Resume_PDF_Formatting_Guide.md` (20 minutes)

**Key Optimizations:**
- ✅ Python expertise emphasized (all interviews in Python)
- ✅ LLM experience front and center (GPT-4, Claude-3, Gemini)
- ✅ Bayesian methods → RLHF connection made explicit
- ✅ "Controlled chaos" language mirrored from job description
- ✅ Production + research balance demonstrated
- ✅ All bullets quantified (10K requests, 67,500 calls, 99.9% reliability)

### 2. Cover Letter ✅
**File:** `Anthropic_Cover_Letter_Research_Engineer.md`  
**Status:** Complete and customized  
**Action:** Copy into application form (if required) or attach as PDF

**Highlights:**
- Opens with production LLM evaluation experience
- Connects Bayesian expertise to RLHF/preference modeling
- Demonstrates "controlled chaos" capability
- Shows alignment with Anthropic mission
- Addresses all key requirements

### 3. "Why Anthropic?" Answer ✅
**Status:** Prepared in cover letter  
**Length:** 300 words (within 200-400 range)  
**Action:** Copy from cover letter "Why Anthropic" section

**Key Points:**
- Mission alignment (reliable, interpretable, steerable AI)
- Research quality (Constitutional AI, RLHF, scaling laws)
- Impact (post-training shapes millions of Claude interactions)

### 4. GitHub Portfolio ⚠️
**Status:** Needs enhancement (from main optimization guide)  
**Priority:** Medium (can apply first, enhance later)  
**Repos:**
- github.com/dereklankeaux/breast-cancer-classification
- github.com/dereklankeaux/llm-ensemble-bias-detection

**Quick enhancement:** Add deployment/ folder to first repo (see GitHub guide)

---

## 📝 Application Form Answers

### Personal Information
- **First Name:** Derek
- **Last Name:** Lankeaux
- **Email:** derek.lankeaux@email.com
- **Phone:** [Your phone]
- **Name Pronunciation:** "DEH-rik LAN-koh"

### Links
- **LinkedIn:** linkedin.com/in/dereklankeaux
- **GitHub:** github.com/dereklankeaux
- **Website:** [Optional]
- **Publications:** [None or Google Scholar if you have]

### Logistics
- **Earliest Start Date:** 2-4 weeks from offer
- **Deadlines:** None
- **Open to Relocation:** Yes (SF/NY/Seattle)
- **Working Address:** "relocating" or West Babylon, NY
- **25% In-Office:** Yes
- **Visa Sponsorship:** [Your answer]

### AI Policy
- **Answer:** Yes
- **Note:** You used Claude to optimize materials - this is encouraged per their policy

### Why Anthropic? ⭐ CRITICAL
**Copy this (311 words):**

```
I'm deeply aligned with Anthropic's mission to create reliable, interpretable, and 
steerable AI systems. Your research on Constitutional AI, RLHF, and scaling laws 
represents exactly the kind of rigorous, empirical AI research I want to contribute to.

My background uniquely positions me for post-training work. At Toloka AI, I evaluate 
frontier LLMs (GPT-4, Claude-3, Gemini) daily, building distributed testing frameworks 
that process 10K+ inferences with systematic evaluation across quality, safety, and 
capability dimensions. This work directly parallels post-training evaluation workflows.

My MS in Applied Statistics brings deep expertise in Bayesian hierarchical modeling—
the statistical foundation for RLHF and preference modeling. My research coordinating 
67,500 API calls across GPT-4, Claude-3, and Llama-3 demonstrates I can work with 
frontier models at production scale while maintaining rigorous statistical validation. 
I understand how to model preferences with uncertainty quantification, aggregate diverse 
feedback, and make principled decisions under ambiguity.

What excites me most is the opportunity to work at the intersection of cutting-edge 
research and production engineering. I thrive in "controlled chaos"—at Toloka, I 
routinely debug complex model issues under time pressure while juggling multiple urgent 
priorities. I balance research exploration (Bayesian methods, novel evaluation 
frameworks) with engineering rigor (fault-tolerant systems, performance optimization).

The impact drives me. Post-training directly shapes how millions of users experience 
Claude—improving capabilities, safety, and alignment at that scale is incredibly 
motivating. I want to help ensure AI systems are beneficial and aligned with human 
values through principled, systematic approaches.

Anthropic's collaborative culture and "big science" approach resonates strongly. I 
learn fastest through research discussions and cross-functional collaboration, and I'm 
excited to contribute to a team pursuing the highest-impact work in AI safety and 
alignment.
```

---

## 🎯 Interview Preparation

### Python Proficiency (CRITICAL)
**Note:** "For this role, we conduct all interviews in Python"

**Prepare:**
- ✅ Review Python fundamentals (data structures, OOP)
- ✅ Practice ML algorithms in Python (no pseudocode)
- ✅ Comfortable with PyTorch patterns (even if not expert)
- ✅ Know async/await, threading, multiprocessing
- ✅ LeetCode Medium problems in Python (practice 10-15)

**Your Strength:** All your work is in Python (Toloka, BRdata, research projects)

### STAR Stories Ready

**"Controlled Chaos" Story:**
```
Situation: Multiple urgent LLM evaluation issues at Toloka during critical product launch
Task: Debug quality degradation while maintaining production pipeline
Action: Systematic evaluation, rapid hypothesis testing, cross-team coordination
Result: Identified root cause (prompt distribution shift), restored quality within 4 hours
```

**"Research + Engineering Balance" Story:**
```
Situation: LLM bias project needed both statistical rigor and production speed
Task: Coordinate 67,500 API calls with Bayesian inference
Action: Built fault-tolerant system with proper statistical validation
Result: 99.5% success rate, Krippendorff's α=0.84, 5-10x optimization
```

**"Debugging Complex Issues" Story:**
```
Situation: NL2SQL system showing inconsistent accuracy (87%)
Task: Debug semantic search without clear error messages
Action: Systematic ablation study, embedding quality analysis, query preprocessing
Result: Improved to 95% accuracy, reduced latency 2.1s → 0.3s
```

### Questions to Ask Anthropic

**About the Role:**
1. "What does a typical week look like? Balance between implementation, research discussions, and debugging?"
2. "How do you evaluate post-training recipe effectiveness? What metrics matter most?"
3. "Can you describe a recent post-training challenge and how it was resolved?"

**About Technical Depth:**
4. "What frameworks does the post-training team primarily use? PyTorch? JAX? Others?"
5. "How does the on-call rotation work for production incidents?"

**About Culture:**
6. "How does the Post-Training team fit into Anthropic's larger research agenda?"
7. "What does success look like in first 6 months?"

---

## ✅ Pre-Submission Checklist

**Before Clicking Submit:**

**Resume:**
- [ ] Formatted as PDF following guide
- [ ] Exactly 1 page
- [ ] Zero typos (proofread 3x)
- [ ] All links work
- [ ] File name: Derek_Lankeaux_Resume_Anthropic_PostTraining.pdf

**Application Form:**
- [ ] All required fields completed
- [ ] "Why Anthropic?" answer ready (200-400 words)
- [ ] LinkedIn profile updated (if time permits)
- [ ] GitHub repos public (if time permits)
- [ ] Cover letter attached (if requested)

**Mental Preparation:**
- [ ] Read Anthropic Constitutional AI paper
- [ ] Read Anthropic RLHF paper
- [ ] Understand Anthropic's mission clearly
- [ ] Practice explaining your Bayesian → RLHF connection

---

## 📊 Why This Role Is Your Best Fit

### Perfect Alignment (75% Match)

**What They Need:**
1. Python expert (all interviews in Python) → ✅ You have this
2. LLM experience → ✅ Daily GPT-4/Claude-3/Gemini evaluation
3. Production + research balance → ✅ Toloka (production) + MS research
4. Distributed systems → ✅ 67,500 API calls, fault tolerance
5. Thrive in controlled chaos → ✅ Production debugging under pressure
6. Bayesian/RLHF understanding → ✅ PyMC expertise, hierarchical models

**Your Unique Value:**
- MS Applied Statistics (rare in engineering roles)
- Bayesian hierarchical modeling → direct RLHF application
- Proven optimization (5-10x documented)
- Production LLM evaluation at scale
- Statistical rigor + engineering execution

**Gaps (Minor):**
- No explicit RLHF implementation (but have all prerequisites)
- No PyTorch production experience (but have concepts)
- No weekend on-call yet (but willing)

**Bottom Line:** This is the best possible role for your background at Anthropic.

---

## 🚀 Next Steps

### Today (30 minutes)
1. ✅ Review this application package
2. ✅ Read `Derek_Lankeaux_Resume_Anthropic_PostTraining.txt`
3. ✅ Read `Anthropic_Cover_Letter_Research_Engineer.md`

### Tomorrow (2 hours)
1. Format resume → PDF (use `Resume_PDF_Formatting_Guide.md`)
2. Proofread everything 3x
3. Update LinkedIn headline (if not done)

### Submit Application (1 hour)
1. Go to Anthropic careers site
2. Find "Research Engineer, Production Model Post Training"
3. Fill out application form
4. Upload resume PDF
5. Paste "Why Anthropic?" answer
6. Submit!

### After Submission
1. Follow up in 1 week if no response
2. Continue applications to other Tier 1 companies
3. Prepare for Python interview questions
4. Read Anthropic research papers

---

## 💰 Compensation Expectations

**Posted Range:** $315,000 - $340,000 base salary  
**Your Target:** $330,000 - $340,000 (high end)  
**Justification:** 
- MS degree + 2 YOE
- Specialized LLM + Bayesian expertise
- Production experience at scale
- Strong research background

**Total Comp Estimate:** $400,000 - $450,000 (including equity)

**Walk-Away:** <$310,000 base (below your market value)

---

## 📈 Expected Timeline

**Week 1:** Application submitted  
**Week 2-3:** Recruiter screen (if passed)  
**Week 4-5:** Technical phone screen (Python coding)  
**Week 6-7:** On-site interviews (4-5 rounds)  
**Week 8:** Offer (if successful)

**Success Probability:** 15-25% (strong application, competitive role)

---

## 🎓 Final Reminders

**Your Strengths:**
- ✅ Technical depth in rare combination (Statistics + LLM + Production)
- ✅ Proven ability to optimize at scale (5-10x documented)
- ✅ Production LLM experience (exactly what they need)
- ✅ Research rigor + engineering execution
- ✅ Mission alignment with AI safety

**What Makes You Unique:**
- Bayesian hierarchical modeling → RLHF preference modeling
- Statistical rigor in ML evaluation
- Production experience with frontier models
- Optimization mindset with proof

**Remember:**
- This is your best-fit role at Anthropic
- You have 75% of requirements (very strong)
- Your unique value proposition is clear
- The "Why Anthropic?" answer is compelling
- You're ready!

---

## 📞 Support

**Questions?**
- Resume formatting: See `Resume_PDF_Formatting_Guide.md`
- Cover letter: See `Anthropic_Cover_Letter_Research_Engineer.md`
- Strategy: See `AI_Industry_2026_Portfolio_Optimization.md`

**Stuck?**
- Focus on getting resume PDF done first
- Everything else is ready to go
- You can apply today if resume is formatted

---

## ✨ You're Ready!

Your application package is **complete and optimized** for this role.

**Time to apply: 2-3 hours** (resume formatting + application form)

**Next action:** Format resume → PDF, then submit application!

**Good luck! This is a great fit for you.** 🚀

---

**Application Prepared:** November 27, 2025  
**Position:** Research Engineer, Production Model Post Training  
**Company:** Anthropic  
**Status:** READY TO SUBMIT ✅
